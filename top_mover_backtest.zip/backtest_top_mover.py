#!/usr/bin/env python3
import os
import time
import math
import json
import toml
import pytz
import queue
import argparse
import datetime as dt
from dataclasses import dataclass
from typing import List, Dict, Optional, Tuple

import requests
import pandas as pd

IST = pytz.timezone("Asia/Kolkata")

COINGECKO_BASE = "https://api.coingecko.com/api/v3"
COINDCX_MARKETS = "https://public.coindcx.com/market_data/exchange_ticker"

# -----------------------------
# Config & Params
# -----------------------------

@dataclass
class Params:
    margin_per_trade: float = 250.0
    leverage: float = 7.0
    tp_with_lev: float = 1.00      # +100% with leverage
    sl_with_lev: float = 0.35      # -35% with leverage
    # Derived real-price thresholds:
    # TP requires +tp_with_lev/leverage, SL requires -sl_with_lev/leverage
    fee_round_trip_pct_notional: float = 0.0012  # 0.12% of notional (both sides total)
    universe_limit: int = 120      # top N tradable pairs from CoinDCX
    days: int = 60                 # backtest window
    verbose: bool = True

def load_config(path: str) -> Dict:
    if not os.path.isfile(path):
        return {}
    return toml.load(path)

# -----------------------------
# Helpers
# -----------------------------

def ts_ist(y, m, d, hh, mm=0, ss=0) -> int:
    local_dt = IST.localize(dt.datetime(y, m, d, hh, mm, ss))
    return int(local_dt.timestamp())

def to_ist_datetime(ts_sec: int) -> dt.datetime:
    return dt.datetime.fromtimestamp(ts_sec, tz=IST)

def http_get_json(url: str, params=None, headers=None, tries: int = 3, sleep=1.0):
    for i in range(tries):
        r = requests.get(url, params=params, headers=headers, timeout=30)
        if r.status_code == 200:
            try:
                return r.json()
            except Exception:
                pass
        time.sleep(sleep * (i+1))
    raise RuntimeError(f"GET failed: {url} {params} {headers}")

def coingecko_coin_id_map() -> Dict[str, str]:
    """Return dict: symbol (uppercase) -> coingecko id"""
    data = http_get_json(f"{COINGECKO_BASE}/coins/list?include_platform=true")
    mapping = {}
    for item in data:
        sym = item.get("symbol","").upper()
        cid = item.get("id","")
        if sym and cid:
            # prefer first occurrence
            if sym not in mapping:
                mapping[sym] = cid
    return mapping

def get_coindcx_universe(limit: int = 120) -> List[Dict]:
    """
    Pull CoinDCX market tickers and select USDT pairs with good volume.
    We'll approximate "futures" by perpetual symbols ending with 'USDT' commonly offered.
    """
    data = http_get_json(COINDCX_MARKETS)
    # data is a list of dicts with keys like 'market', 'last_price', 'volume', etc.
    # Filter USDT markets and sort by 24h volume (quote)
    usdt = [x for x in data if isinstance(x.get("market"), str) and x["market"].endswith("USDT")]
    # Try to parse volume as quote volume if available; fall back to base*price if fields exist.
    def vol_est(x):
        try:
            return float(x.get("volume", 0.0))
        except:
            return 0.0
    usdt.sort(key=vol_est, reverse=True)
    return usdt[:limit]

def coingecko_price_at(coin_id: str, vs: str, t_sec: int) -> Optional[float]:
    """
    Get price near timestamp t using /market_chart/range. Returns closest price.
    """
    start = t_sec - 60*60*3   # 3h window before
    end   = t_sec + 60*60*3   # 3h window after
    url = f"{COINGECKO_BASE}/coins/{coin_id}/market_chart/range"
    data = http_get_json(url, params={"vs_currency": vs, "from": start, "to": end})
    prices = data.get("prices", [])
    if not prices:
        return None
    # choose nearest timestamp
    best = min(prices, key=lambda p: abs(int(p[0]/1000) - t_sec))
    return float(best[1])

def coingecko_series(coin_id: str, vs: str, start_sec: int, end_sec: int) -> pd.DataFrame:
    url = f"{COINGECKO_BASE}/coins/{coin_id}/market_chart/range"
    data = http_get_json(url, params={"vs_currency": vs, "from": start_sec, "to": end_sec})
    prices = data.get("prices", [])
    if not prices:
        return pd.DataFrame(columns=["ts","price"])
    df = pd.DataFrame(prices, columns=["ms","price"])
    df["ts"] = (df["ms"] / 1000).astype(int)
    df = df.drop(columns=["ms"]).drop_duplicates("ts").sort_values("ts")
    return df

def pick_top_mover_at(ts_sec: int, universe: List[Dict], sym_to_cgid: Dict[str,str]) -> Optional[Tuple[str, float]]:
    """
    For each symbol in universe, compute 24h % change as:
        (P(t) - P(t-24h)) / P(t-24h)
    Return (symbol, pct_change) with maximum change.
    """
    best = None
    t_minus = ts_sec - 24*3600
    for m in universe:
        market = m.get("market","")
        # Expect like "ABCUSDT" => symbol is base without 'USDT'
        if not market.endswith("USDT") or len(market) <= 4:
            continue
        base = market[:-4]
        cgid = sym_to_cgid.get(base.upper())
        if not cgid:
            continue
        p_t = coingecko_price_at(cgid, "usd", ts_sec)
        p_tm = coingecko_price_at(cgid, "usd", t_minus)
        if p_t is None or p_tm is None or p_tm <= 0:
            continue
        chg = (p_t - p_tm) / p_tm
        if (best is None) or (chg > best[1]):
            best = (market, chg)
    return best

def simulate_trade(coin_id: str, entry_ts: int, entry_price: float, lev: float, tp_with_lev: float, sl_with_lev: float) -> Tuple[str, float, int, float]:
    """
    Walk forward using 5m-ish points (as returned by coingecko) and stop at first hit.
    Returns (outcome, exit_price, exit_ts, move_real)
    outcome: 'TP' or 'SL' or 'NEITHER'
    """
    tp_move = tp_with_lev / lev
    sl_move = sl_with_lev / lev
    start = entry_ts
    end   = entry_ts + 36*3600  # search up to 36h after entry
    df = coingecko_series(coin_id, "usd", start, end)
    if df.empty:
        return ("NEITHER", entry_price, entry_ts, 0.0)
    # Ensure first point is at/near entry
    # Iterate in time
    for _, row in df.iterrows():
        price = float(row["price"])
        move = (price - entry_price) / entry_price
        if move >= tp_move:
            return ("TP", price, int(row["ts"]), move)
        if move <= -sl_move:
            return ("SL", price, int(row["ts"]), move)
    # If neither hit in 36h, mark neither and exit at last price
    last_price = float(df.iloc[-1]["price"])
    last_move = (last_price - entry_price)/entry_price
    return ("NEITHER", last_price, int(df.iloc[-1]["ts"]), last_move)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.toml", help="Path to config TOML")
    ap.add_argument("--days", type=int, default=None, help="Override days")
    ap.add_argument("--universe", type=int, default=None, help="Override universe size")
    args = ap.parse_args()

    cfg = {}
    if os.path.isfile(args.config):
        cfg = toml.load(args.config)

    p = Params()
    for k, v in cfg.get("params", {}).items():
        if hasattr(p, k):
            setattr(p, k, v)

    if args.days: p.days = args.days
    if args.universe: p.universe_limit = args.universe

    # Step 1: Universe from CoinDCX
    print("Fetching CoinDCX markets...")
    uni_raw = get_coindcx_universe(p.universe_limit)

    # Step 2: Map symbols to CoinGecko IDs
    print("Building CoinGecko symbol map...")
    sym_map = coingecko_coin_id_map()

    # Prepare date list for last p.days
    now_ist = dt.datetime.now(IST)
    dates = [(now_ist - dt.timedelta(days=i)).date() for i in range(1, p.days+1)]
    dates = sorted(dates)  # oldest -> newest

    rows = []
    total_trades = 0
    wins = 0
    losses = 0
    neither = 0

    for dte in dates:
        for hh in (8, 20):  # 8 AM, 8 PM IST
            ts = ts_ist(dte.year, dte.month, dte.day, hh, 0, 0)
            print(f"\n[{dte} {hh:02d}:00 IST] Selecting Top Mover...")
            tm = pick_top_mover_at(ts, uni_raw, sym_map)
            if not tm:
                print("  No top mover found (data missing). Skipping.")
                continue
            market, chg24 = tm
            base = market[:-4].upper()
            cgid = sym_map.get(base)
            if not cgid:
                print(f"  No CoinGecko id for {base}. Skipping.")
                continue

            entry_price = coingecko_price_at(cgid, "usd", ts)
            if entry_price is None:
                print("  Entry price not found. Skipping.")
                continue

            outcome, exit_price, exit_ts, move_real = simulate_trade(
                cgid, ts, entry_price, p.leverage, p.tp_with_lev, p.sl_with_lev
            )

            # P&L on margin basis
            if outcome == "TP":
                pnl = p.margin_per_trade * p.tp_with_lev
                wins += 1
            elif outcome == "SL":
                pnl = -p.margin_per_trade * p.sl_with_lev
                losses += 1
            else:
                # Neither: close at exit price (mark-to-market)
                pnl = p.margin_per_trade * p.leverage * move_real  # MTM on leverage
                neither += 1

            # Fees
            notional = p.margin_per_trade * p.leverage
            fees = notional * p.fee_round_trip_pct_notional
            net_pnl = pnl - fees

            rows.append({
                "date": str(dte),
                "time_ist": f"{hh:02d}:00",
                "market": market,
                "entry_ts": ts,
                "entry_price_usd": entry_price,
                "choice_24h_change": chg24,
                "exit_ts": exit_ts,
                "exit_time_ist": to_ist_datetime(exit_ts).strftime("%Y-%m-%d %H:%M:%S"),
                "exit_price_usd": exit_price,
                "move_real_pct": round(move_real*100, 3),
                "outcome": outcome,
                "gross_pnl_inr": round(pnl, 2),
                "fees_inr": round(fees, 2),
                "net_pnl_inr": round(net_pnl, 2),
            })
            total_trades += 1
            print(f"  {market} | outcome={outcome} | net P&L ₹{net_pnl:.2f}")

    if not rows:
        print("No trades generated. Check API/data availability.")
        return

    df = pd.DataFrame(rows)
    df.to_csv("backtest_results.csv", index=False)

    summary = {
        "trades": total_trades,
        "wins": wins,
        "losses": losses,
        "neither": neither,
        "win_rate_pct": round(100 * wins / max(1, total_trades), 2),
        "gross_pnl_inr": round(float(df["gross_pnl_inr"].sum()), 2),
        "fees_inr": round(float(df["fees_inr"].sum()), 2),
        "net_pnl_inr": round(float(df["net_pnl_inr"].sum()), 2),
        "avg_net_per_trade_inr": round(float(df["net_pnl_inr"].mean()), 2),
    }
    with open("backtest_summary.json","w") as f:
        json.dump(summary, f, indent=2)

    print("\n==== SUMMARY ====")
    print(json.dumps(summary, indent=2))
    print("Results saved: backtest_results.csv, backtest_summary.json")

if __name__ == "__main__":
    main()

# Top Mover Backtest (CoinDCX-like, with CoinGecko prices)

**What it does**
- Reconstructs the "Top Mover" at **08:00** and **20:00 IST** for the last **60 days** from a CoinDCX USDT-quoted universe.
- Uses CoinGecko historical prices to compute 24h change at those timestamps and pick the top mover.
- Enters at timestamp price; exits on first hit of:
  - **TP 100% with 7× leverage** ⇒ **≈ +14.29%** real price move
  - **SL 35% with 7× leverage** ⇒ **≈ −5%** real price move
- Saves detailed trade log (`backtest_results.csv`) and a JSON summary (`backtest_summary.json`).

> Note: CoinDCX does not publish historical "Top Mover" snapshots. This script *reconstructs* them from price changes (approximation).

## How to run

### 1) Create a virtual env (recommended)
```bash
python -m venv .venv
. .venv/bin/activate  # on Windows: .venv\Scripts\activate
```

### 2) Install requirements
```bash
pip install -r requirements.txt
```

### 3) Configure parameters
Copy `config.example.toml` -> `config.toml` and edit if needed:
```toml
[params]
margin_per_trade = 250.0
leverage = 7.0
tp_with_lev = 1.0
sl_with_lev = 0.35
fee_round_trip_pct_notional = 0.0012
universe_limit = 120
days = 60
```

### 4) Run
```bash
python backtest_top_mover.py --config config.toml
```

### Output files
- `backtest_results.csv` – trade-by-trade details
- `backtest_summary.json` – totals and win-rate

## Notes & Tips
- If CoinGecko rate limits you, re-run later or reduce `universe_limit` or `days`.
- This script uses **USD** prices for selection/simulation. If you want INR P&L on notional fees, adjust `fee_round_trip_pct_notional` or add a live FX conversion.
- To strictly use only coins tradeable on CoinDCX Futures, you can modify the universe filter logic to include only those symbols you trade.
- You can extend `simulate_trade()` to use exchange-native candles if you have a direct historical endpoint.